<?php
namespace Mobicommerce\Area\Block\Adminhtml\User\Edit;
class Custom extends \Magento\Backend\Block\Template
{

}
