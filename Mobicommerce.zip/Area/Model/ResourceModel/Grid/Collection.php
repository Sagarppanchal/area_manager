<?php

/**
 * Area Grid Collection.
 *
 * @author sagarppanchal@21062018
 */
namespace Mobicommerce\Area\Model\ResourceModel\Grid;

/* use required classes */
use Magento\Framework\Data\Collection\EntityFactoryInterface;
use Psr\Log\LoggerInterface;
use Magento\Framework\Data\Collection\Db\FetchStrategyInterface;
use Magento\Framework\Event\ManagerInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\DB\Adapter\AdapterInterface;
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = 'entity_id';
    /**
     * Define resource model.
     */
    // protected function _construct()
    // {
    //     $this->_init(
    //         'Mobicommerce\Area\Model\Grid',
    //         'Mobicommerce\Area\Model\ResourceModel\Grid'
    //     );
    // }

    public function __construct(
        EntityFactoryInterface $entityFactory,
        LoggerInterface $logger,
        FetchStrategyInterface $fetchStrategy,
        ManagerInterface $eventManager,
        StoreManagerInterface $storeManager,
        AdapterInterface $connection = null,
        AbstractDb $resource = null
    ) {
        $this->_init('Mobicommerce\Area\Model\Grid', 'Mobicommerce\Area\Model\ResourceModel\Grid');
        //Class naming structure 
        // 'NameSpace\ModuleName\Model\ModelName', 'NameSpace\ModuleName\Model\ResourceModel\ModelName'
        parent::__construct($entityFactory, $logger, $fetchStrategy, $eventManager, $connection, $resource);
        $this->storeManager = $storeManager;
    }

    // protected function _initSelect()
    // {
    //     parent::_initSelect();

    //     $this->getSelect()->joinLeft(
    //             ['admin_user' => $this->getTable('admin_user')],
    //             'mobicommerce_area_records.users = admin_user.entity_id',
    //             ['email'=>'email']
    //         );
    //     $this->addFilterToMap('email', 'admin_user.email');

    //     //$this->addFilterToMap('columnname2_clias', 'secondTable.columnname2');
    //     return $this;
    // }

    protected function _initSelect()
    {
        parent::_initSelect();
 
        $this->getSelect()->joinLeft(
            ['secondTable' => $this->getTable('admin_user')], //2nd table name by which you want to join mail table
            'main_table.users = secondTable.user_id', // common column which available in both table 
            'email' // '*' define that you want all column of 2nd table. if you want some particular column then you can define as ['column1','column2']
        );

        $this->addFilterToMap('email', 'secondTable.email');

        return $this;
    }

}
