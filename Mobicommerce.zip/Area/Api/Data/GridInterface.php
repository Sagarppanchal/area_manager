<?php
/**
 * Area GridInterface.
 * @author sagarppanchal@21062018
 */

namespace Mobicommerce\Area\Api\Data;

interface GridInterface
{
    /**
     * Constants for keys of data array. Identical to the name of the getter in snake case.
     */
    const ENTITY_ID = 'entity_id';
    const TITLE = 'title';
    const USERS = 'users';
    const EMAIL = 'email';
    
   /**
    * Get EntityId.
    *
    * @return int
    */
    public function getEntityId();

   /**
    * Set EntityId.
    */
    public function setEntityId($entityId);

   /**
    * Get Title.
    *
    * @return varchar
    */
    public function getTitle();

   /**
    * Set Title.
    */
    public function setTitle($title);

   /**
    * Get Users.
    *
    * @return varchar
    */
    public function getUsers();

   /**
    * Set Users.
    */
    public function setUsers($content);

    public function getEmail();

    public function setEmail($content);
}
