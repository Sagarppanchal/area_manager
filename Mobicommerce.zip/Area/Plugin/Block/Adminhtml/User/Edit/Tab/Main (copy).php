<?php
    
/**
 * Add Delivery Area Field 
 * @author sagarppanchal@22062018
*/

namespace Mobicommerce\Area\Plugin\Block\Adminhtml\User\Edit\Tab;

class Main
{

    public function __construct(
    \Magento\Framework\Webapi\Rest\Request $request
    ) {
        $this->_request = $request;
    }
    /**
     * Get form HTML
     *
     * @return string
     */
    public function aroundGetFormHtml(
        \Magento\User\Block\User\Edit\Tab\Main $subject,
        \Closure $proceed
    )
    {
        $form = $subject->getForm();

        if (is_object($form)) {

            $objectManager =   \Magento\Framework\App\ObjectManager::getInstance();
            $connection = $objectManager->get('Magento\Framework\App\ResourceConnection')->getConnection('\Magento\Framework\App\ResourceConnection::DEFAULT_CONNECTION'); 
            $result1 = $connection->fetchAll("SELECT * FROM mobicommerce_area_records");

            $allArea=[];

            if($result1) {
                foreach($result1 as $k=>$v) {
                    $allArea[$k]['label']=$v['title'];
                    $allArea[$k]['value']=$v['entity_id'];
                }
                
            }

            $fieldset = $form->addFieldset('user_base_fieldset', ['legend' => __('Delivery Area')]);
            $fieldset->addField(
                'delivery_area',
                'multiselect',
                [
                    'name' => 'delivery_area',
                    'label' => __('Delivery Area'),
                    //'style' => 'height:36em;',
                    //'required' => true,
                    'title' => __('Delivery Area'),
                    'values' => $allArea
                ]
            );

            $subject->setForm($form);
        }

        return $proceed();
    }
}