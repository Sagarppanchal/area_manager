<?php
namespace Nadim\ExpressService\Controller\ExpressService;

//use Magento\Framework\Controller\ResultFactory;

class Service extends \Magento\Framework\App\Action\Action
{

    protected $resultPageFactory;

  

    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
        \Magento\Checkout\Model\Session $checkoutSession
    ) {
        $this->resultPageFactory = $resultPageFactory;
        $this->resultJsonFactory = $resultJsonFactory;
        $this->checkoutSession = $checkoutSession;

        parent::__construct($context);
    }

    public function execute()
    {

       $data = $this->getRequest()->getParams();
       if ($data) {

            $serviceName        = $data['service_name'];
            $serviceType        = $data['type'];
            $servicePrice       = $data['price'];
            $serviceDescription = $data['description'];
            $serviceMinHours    = $data['min_hour'];
            $serviceMaxHours    = $data['max_hour'];

            $quote =  $this->checkoutSession->getQuote(); 
           echo $quote->getId();
            $quote->setServiceName($serviceName);
            $quote->setType($serviceType);
            $quote->setServicePrice($servicePrice);
            $quote->setDescription($serviceDescription);
            $quote->setMinHour($serviceMinHours);
            $quote->setMaxHour($serviceMaxHours);
            $quote->save();
           return ;
        }

    return ;

         

    }

}
