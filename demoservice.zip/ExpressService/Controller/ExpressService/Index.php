<?php
namespace Nadim\ExpressService\Controller\ExpressService;
//use Magento\Framework\Controller\ResultFactory;

class Index extends \Magento\Framework\App\Action\Action
{

      protected $resultPageFactory;

    public function __construct(
       \Magento\Framework\App\Action\Context $context,
       \Magento\Framework\View\Result\PageFactory $resultPageFactory,
       //\Nadim\ExpressService\Model\ResourceModel\Service\CollectionFactory $collectionFactory,
       \Magento\Framework\Controller\Result\JsonFactory    $resultJsonFactory
   )
   {
       $this->resultPageFactory  = $resultPageFactory;
      // $this->collectionFactory  = $collectionFactory;
        $this->resultJsonFactory = $resultJsonFactory;
       parent::__construct($context);
   }

   public function execute()
   {
      $resultJson = $this->resultJsonFactory->create();

      $objectManager = \Magento\Framework\App\ObjectManager::getInstance();   

      $serviceCollectionFactory = $objectManager->create('Nadim\ExpressService\Model\Service')->getCollection();
      $serviceCollection = $serviceCollectionFactory->addFieldToSelect('*')
       ->addFieldToFilter('status',1);
       $resultJson->setData($serviceCollection); 
      return $resultJson; 
      //echo json_encode($serviceCollection);
      //return;

   }
    
}
