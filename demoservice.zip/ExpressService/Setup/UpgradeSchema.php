<?php

namespace Nadim\ExpressService\Setup;

use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\UpgradeSchemaInterface;

class UpgradeSchema implements UpgradeSchemaInterface
{

    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {

        $setup->startSetup();

        if (version_compare($context->getVersion(), '1.0.1') < 0) {

            $quoteTable = $setup->getTable('quote');
            if ($setup->getConnection()->isTableExists($quoteTable) == true) {
                $columns = [

                    'service_name' => [
                        'type'     => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                        'nullable' => true,
                        'comment'  => 'Service Name',
                    ],

                    'type'         => [
                        'type'     => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                        'nullable' => true,
                        'comment'  => 'Service Type',
                    ],

                    'service_price' => [
                        'type'     => \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                        'nullable' => true,
                        'comment'  => 'Service Price',
                    ],

                    'description'  => [
                        'type'     => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                        'nullable' => true,
                        'comment'  => 'Service Description',
                    ],

                    'min_hour'     => [
                        'type'     => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                        'nullable' => true,
                        'comment'  => 'min_hour ',
                    ],

                    'max_hour'     => [
                        'type'     => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                        'nullable' => true,
                        'comment'  => 'max_hour',
                    ],

                ];

                $connection = $setup->getConnection();

                foreach ($columns as $name => $definition) {

                    $connection->addColumn($quoteTable, $name, $definition);

                }

            }

            $orderTable = $setup->getTable('sales_order');
            if ($setup->getConnection()->isTableExists($orderTable) == true) {

                $columns = [

                    'service_name' => [
                        'type'     => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                        'nullable' => true,
                        'comment'  => 'Service Name',
                    ],

                    'type'         => [
                        'type'     => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                        'nullable' => true,
                        'comment'  => 'Service Type',
                    ],

                    'service_price' => [
                        'type'     => \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                        'nullable' => true,
                        'comment'  => 'Service Price',
                    ],

                    'description'  => [
                        'type'     => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                        'nullable' => true,
                        'comment'  => 'Service Description',
                    ],

                    'min_hour'     => [
                        'type'     => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                        'nullable' => true,
                        'comment'  => 'min_hour ',
                    ],

                    'max_hour'     => [
                        'type'     => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                        'nullable' => true,
                        'comment'  => 'max_hour',
                    ],

                ];

                $connection = $setup->getConnection();
                foreach ($columns as $name => $definition) {
                   $connection->addColumn($orderTable, $name, $definition);
                }

            }

        }

        $setup->endSetup();

    }

}
