<?php
namespace Nadim\ExpressService\Observer;
use Magento\Framework\Event\ObserverInterface;

class SaveExpressServiceObserver implements ObserverInterface
{
    /*public function __construct(
        \Psr\Log\LoggerInterface $logger,
        \Magento\Quote\Api\CartRepositoryInterface $quoteRepository    
    ) {

        $this->logger = $logger;
        $this->quoteRepository = $quoteRepository;
    }*/

    public function execute(\Magento\Framework\Event\Observer $observer)
    {   
        
        $order = $observer->getEvent()->getOrder();

        $quote = $observer->getEvent()->getQuote();
        $order->setServiceName($quote->getServiceName());
        $order->setType($quote->getType());
        $order->setServicePrice($quote->getServicePrice());
        $order->setDescription($quote->getDescription());
        $order->setMinHour($quote->getMinHour());
        $order->setMaxHour($quote->getMaxHour());
        $order->save();
        return;

    }


 
}
