<?php
namespace Nadim\ExpressService\Observer;
use Magento\Framework\Event\ObserverInterface;

class SaveExpressServiceObserver implements ObserverInterface
{
    /**
     * @param \Magento\Framework\Event\Observer $observer
    */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        echo "Hello";

die;
        $order = $observer->getEvent()->getOrder();
        $quote = $observer->getEvent()->getquote();

        echo $quote->getServiceName(); 


        $order->setServiceName($quote->getServiceName());
        $order->setType($quote->getType());
        $order->setServicePrice($quote->getServicePrice());
        $order->setDescription($quote->getDescription());
        $order->setMinHour($quote->getMinHour());
        $order->setMaxHour($quote->getMaxHour());
        $order->save();

        return; 
    }
}
