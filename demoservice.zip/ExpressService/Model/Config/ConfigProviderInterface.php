<?php 
namespace Nadim\ExpressService\Model\Config;

use Magento\Checkout\Model\ConfigProviderInterface;

class ConfigProvider implements ConfigProviderInterface
{

    /**
     * Retrieve assoc array of checkout configuration
     *
     * @return array
     */
    public function getConfig()
    {
        return [
            'managers' => [
                'members' => $this->getActiveMembers()
            ]
        ];
    }


     public function getActiveMembers()
    {
        $options = ['free' => __('Free'), 'cart' => __('Cart'), 'product' => __('Product')];

        return $options;
    }



}
