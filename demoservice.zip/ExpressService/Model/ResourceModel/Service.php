<?php
/**
 * Copyright © 2015 Nadim. All rights reserved.
 */
namespace Nadim\ExpressService\Model\ResourceModel;

/**
 * Service resource
 */
class Service extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Initialize resource
     *
     * @return void
     */
    public function _construct()
    {
        $this->_init('express_service', 'id');
    }

}
