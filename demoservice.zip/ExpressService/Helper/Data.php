<?php
/**
 * Copyright © 2015 Nadim . All rights reserved.
 */
namespace Nadim\ExpressService\Helper;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{

    /**
     * @param \Magento\Framework\App\Helper\Context $context
     */
    public function __construct(\Magento\Framework\App\Helper\Context $context
    ) {
        parent::__construct($context);
    }

    public function toOptionArray()
    {
        $options = ['Free' => __('Free'), 'Cart' => __('Cart'), 'Product' => __('Product')];

        return $options;
    }

}
