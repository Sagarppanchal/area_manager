  define(
    [
        'ko',
        'uiComponent',
        'underscore',
        'Magento_Checkout/js/model/step-navigator',
        'Magento_Customer/js/model/customer',
        'mage/url',
        'jquery',
        'Magento_Checkout/js/model/quote',
        'Magento_Customer/js/customer-data',
        'Magento_Checkout/js/model/cart/totals-processor/default',
        'Magento_Checkout/js/model/cart/cache'
    ],
    function (
        ko,
        Component,
        _,
        stepNavigator,
        customer,
         urlBuilder,
        $,
        quote,
        customerData,
        defaultTotal, 
        cartCache
    ) {
        'use strict';
        /**
        *
        * mystep - is the name of the component's .html template, 
        * <Vendor>_<Module>  - is the name of the your module directory.
        * 
        */
        return Component.extend({   
            defaults: {
                template: 'Nadim_ExpressService/service'
            },
            express_service_name: ko.observable(),
            express_service_price: ko.observable(),
            express_service_desc: ko.observable(),
            express_service_min_hours: ko.observable(),
            express_service_max_hours: ko.observable(),
            express_service_type: ko.observable(),
            selected_express_service: ko.observable(),
            /**
             * retrieve data to form update
             */
            //add here your logic to display step,
             isVisible: ko.observable(true),
         
             getServiceId: function (scope,elem)
             {
                var serviceId  = $(elem.target).val(); 

                var $_this = this;

                  $_this.selected_express_service =false;   
                 $_this.express_service_name('');
                        $_this.express_service_price('');
                        $_this.express_service_desc('');
                        $_this.express_service_min_hours('');
                        $_this.express_service_max_hours('');
                        $_this.express_service_type('');
                $.each(scope.contacts,function(index,val){

                    if(val.id == serviceId)
                    {
                        $_this.selected_express_service = val;
                        $_this.express_service_name(val.service_name);
                        $_this.express_service_price(val.price);
                        $_this.express_service_desc(val.description);
                        $_this.express_service_min_hours(val.min_hour);
                        $_this.express_service_max_hours(val.max_hour);
                        $_this.express_service_type(val.type);
                        quote.service_price = val.price;
                    }
                })

              //this.getServiceDetailsById(this,serviceId);
              //console.log(this);
              return this;
              
            },
            /**
            *
            * @returns {*}
            */
            initialize: function () {
                this._super();
                cartCache.set('totals',null);
             
                this.servicedata = [];
                // register your step
                stepNavigator.registerStep(
                    //step code will be used as step content id in the component template
                    'express_service',
                    //step alias
                    null,
                    //step title value
                    'Express Service',
                    //observable property with logic when display step or hide step
                    this.isVisible,

                    _.bind(this.navigate, this),

                    /**
                    * sort order value
                    * 'sort order value' < 10: step displays before shipping step;
                    * 10 < 'sort order value' < 20 : step displays between shipping and payment step
                    * 'sort order value' > 20 : step displays after payment step
                    */
                    15
                );
                this.getService(this);
             

                return this;
            },


            /* Validation Form*/
            validateForm: function (form) {
                 return $(form).validation() && $(form).validation('isValid');
            },

              /**
         * Form submit handler
         *
         * This method can have any name.
         */
        onSubmit: function() {

            var $_this = this;

           if (!$_this.validateForm('#my-new-step-form')) {
                return;
            }
          

           if($_this.selected_express_service)      
           {

               var serviceUrl = urlBuilder.build('expressservice/expressservice/service');
                console.log(serviceUrl);
                  $.ajax({
                    url: serviceUrl,
                    type: 'POST',
                    data: $_this.selected_express_service,
                    async: false,
                    showLoader  :true,
                    success:function(data){
                       // customerData.reload(['cart'], false);
                        cartCache.set('totals',null);
                        defaultTotal.estimateTotals();
                       //console.log("done");
                       $_this.navigateToNextStep();
                    }
                });

           }

           return  $_this;
           
        },



            /**
            * The navigate() method is responsible for navigation between checkout step
            * during checkout. You can add custom logic, for example some conditions
            * for switching to your custom step 
            */
            navigate: function () {
               
            },

            /**
            * @returns void
            */
            navigateToNextStep: function () {
                //this.saveContact();
                stepNavigator.next();
            },

            /**
             * Get All the Express Service Details 
             * @param {Object} scope 
             * @returns void
             */
            getService: function(scope){
                //console.log("Hello Loging");
                console.log(scope)
               // var serviceUrl = urlBuilder.build('knockout/test/product?id='+id);
                var serviceUrl = urlBuilder.build('expressservice/expressservice/index');
                console.log(serviceUrl);
                  $.ajax({
                    url: serviceUrl,
                    type: 'POST',
                    dataType: "json",
                    async: false,
                    success:function(data){
                        
                        scope.contacts = data.items;
                    }
                });

            },
          


        });
    }
);