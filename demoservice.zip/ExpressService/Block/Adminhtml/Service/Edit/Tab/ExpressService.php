<?php
namespace Nadim\ExpressService\Block\Adminhtml\Service\Edit\Tab;

class ExpressService extends \Magento\Backend\Block\Widget\Form\Generic implements \Magento\Backend\Block\Widget\Tab\TabInterface
{
    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_systemStore;

    /**
     * @var \Nadim\ExpressService\Helper\Data
     */
    protected $_dataHelper;

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Data\FormFactory $formFactory
     * @param \Magento\Store\Model\System\Store $systemStore
     * @param \Nadim\ExpressService\Helper\Data $dataHelper
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Store\Model\System\Store $systemStore,
        \Nadim\ExpressService\Helper\Data $dataHelper,
        array $data = array()
    ) { 
        $this->_systemStore = $systemStore;
        $this->_dataHelper  = $dataHelper;
        parent::__construct($context, $registry, $formFactory, $data);
    }



     public function _prepareLayout()
     {
           //set page title
           $this->pageConfig->getTitle()->set(__('Express Service'));

           return parent::_prepareLayout();
     } 

    /**
     * Prepare form
     *
     * @return $this
     */
    protected function _prepareForm()
    {
        /* @var $model \Magento\Cms\Model\Page */
        $model             = $this->_coreRegistry->registry('expressservice_service');
        $isElementDisabled = false;
        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create();

        $form->setHtmlIdPrefix('page_');

        $fieldset = $form->addFieldset('base_fieldset', array('legend' => __('Express Service')));

        if ($model->getId()) {
            $fieldset->addField('id', 'hidden', array('name' => 'id'));
        }
        $fieldset->addField(
            'service_name',
            'text',
            array(
                'name'     => 'service_name',
                'label'    => __('Service Name'),
                'title'    => __('Service Name'),
                'required' => true,
            )
        );

        $fieldset->addField(
            'type',
            'select',
            array(
                'name'     => 'type',
                'label'    => __('Type'),
                'title'    => __('Type'),
                'values'   => $this->_dataHelper->toOptionArray(),
                'required' => true,
            )
        );
        $fieldset->addField(
            'price',
            'text',
            array(
                'name'     => 'price',
                'label'    => __('Price'),
                'title'    => __('Price'),
                'required' => true,
            )
        );

        $fieldset->addField(
            'description',
            'textarea',
            array(
                'name'     => 'description',
                'label'    => __('Description'),
                'title'    => __('Description'),
                'required' => true,
            )
        );

        $fieldset->addField(
            'min_hour',
            'text',
            array(
                'name'     => 'min_hour',
                'label'    => __('Min Hour'),
                'title'    => __('Min Hour'),
                'required' => true,
            )
        );
        $fieldset->addField(
            'max_hour',
            'text',
            array(
                'name'     => 'max_hour',
                'label'    => __('Max Hour'),
                'title'    => __('Max Hour'),
                'required' => true,
            )
        );

        $fieldset->addField(
            'status',
            'select',
            ['name' => 'status', 'options' => [1 => __('Enable'), 0 => __('Disable')], 'label' => __('Status'), 'title' => __('Status'), 'required' => true]
        );

        if (!$model->getId()) {
            $model->setData('status', $isElementDisabled ? '2' : '1');
        }

        $form->setValues($model->getData());
        $this->setForm($form);

        return parent::_prepareForm();
    }

    /**
     * Prepare label for tab
     *
     * @return string
     */
    public function getTabLabel()
    {
        return __('Express Service');
    }

    /**
     * Prepare title for tab
     *
     * @return string
     */
    public function getTabTitle()
    {
        return __('Express Service');
    }

    /**
     * {@inheritdoc}
     */
    public function canShowTab()
    {
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function isHidden()
    {
        return false;
    }

    /**
     * Check permission for passed action
     *
     * @param string $resourceId
     * @return bool
     */
    protected function _isAllowedAction($resourceId)
    {

        return $this->_authorization->isAllowed($resourceId);
    }
}
