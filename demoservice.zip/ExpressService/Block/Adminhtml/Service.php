<?php
namespace Nadim\ExpressService\Block\Adminhtml;

class Service extends \Magento\Backend\Block\Widget\Grid\Container
{
    /**
     * Constructor
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_controller     = 'adminhtml_service'; /*block grid.php directory*/
        $this->_blockGroup     = 'Nadim_ExpressService';
        $this->_headerText     = __('Service');
        $this->_addButtonLabel = __('Add Service');
        parent::_construct();

    }
}
