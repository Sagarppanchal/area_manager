<?php
namespace Mobicommerce\Area\Block\Adminhtml\Order\View;
class Custom extends \Magento\Backend\Block\Template
{

}
