<?php

/**
 * Area Ui Component Action.
 * @author sagarppanchal@21062018
 */
namespace Mobicommerce\Area\Ui\Component\Listing;


class AreaDataProvider extends \Magento\Framework\View\Element\UiComponent\DataProvider\SearchResult
{
   protected function _initSelect()
   {
      parent::_initSelect();
      $this->getSelect()->joinLeft(
        ['secondTable' => $this->getTable('admin_user')],
        'main_table.users = secondTable.user_id',
        ['email']
      );
      return $this;
  }
}

?>