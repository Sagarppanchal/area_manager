<?php
/**
 * Grid Module registration.
 * @author    sagarppanchal@21062018
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Mobicommerce_Area',
    __DIR__
);
