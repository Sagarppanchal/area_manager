<?php
/**
 * Area Schema Setup.
 * @author sagarppanchal@21062018
 */

namespace Mobicommerce\Area\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\App\Filesystem\DirectoryList;

/* For get RoleType and UserType for create Role   */;
use Magento\Authorization\Model\Acl\Role\Group as RoleGroup;
use Magento\Authorization\Model\UserContextInterface;

/**
 * @codeCoverageIgnore
*/

class InstallSchema implements InstallSchemaInterface
{
    /**
     * {@inheritdoc}
     *
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
    */

    /**
     * RoleFactory
     *
     * @var roleFactory
     */
    private $roleFactory;
 
     /**
     * RulesFactory
     *
     * @var rulesFactory
     */
    private $rulesFactory;
    /**
     * Init
     *
     * @param \Magento\Authorization\Model\RoleFactory $roleFactory
     * @param \Magento\Authorization\Model\RulesFactory $rulesFactory
    */

    /**
     * Init
     *
     * @param \Magento\Authorization\Model\RoleFactory $roleFactory
     * @param \Magento\Authorization\Model\RulesFactory $rulesFactory
    */

    public function __construct(
        \Magento\Authorization\Model\RoleFactory $roleFactory, /* Instance of Role*/
        \Magento\Authorization\Model\RulesFactory $rulesFactory /* Instance of Rule */
        /*this define that which resource permitted to wich role */
    ) {
        $this->roleFactory = $roleFactory;
        $this->rulesFactory = $rulesFactory;
    }

    public function install(
        SchemaSetupInterface $setup,
        ModuleContextInterface $context
    ) {
        $installer = $setup;

        $installer->startSetup();

        /*
         * Create table 'mobicommerce_area_records'
         */

        $table = $installer->getConnection()->newTable(
            $installer->getTable('mobicommerce_area_records')
        )->addColumn(
            'entity_id',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            null,
            ['identity' => true, 'nullable' => false, 'primary' => true],
            'area Id'
        )->addColumn(
            'title',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            255,
            ['nullable' => false],
            'Title'
        )->addColumn(
            'users',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            '2M',
            ['nullable' => false],
            'Post'
        )->setComment(
            'Row Data Table'
        );

        $installer->getConnection()->createTable($table);

        // area manager in sales order table

        $installer->getConnection()
        ->addColumn($installer->getTable('sales_order_grid'),'area_manager', array(
            'type'      => \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            'nullable'  => false,
            'length'    => 255,
            'after'     => null,
            'comment'   => 'Area Manager'
            ));
        $installer->getConnection()->createTable($table);

        $installer->getConnection()
        ->addColumn($installer->getTable('sales_order'),'area_manager', array(
            'type'      => \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            'nullable'  => false,
            'length'    => 255,
            'after'     => null,
            'comment'   => 'Area Manager'
            ));
        $installer->getConnection()->createTable($table);

        //add delivery_area in users table

        $installer->getConnection()
        ->addColumn($installer->getTable('admin_user'),'delivery_area', array(
            'type'      => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            'nullable'  => false,
            'length'    => 255,
            'after'     => null,
            'comment'   => 'Area to deliver'
            ));
        $installer->getConnection()->createTable($table);

        //add manager devicetokens for admin app

        $table = $installer->getConnection()->newTable(
            $installer->getTable('mobicommerce_manager_devicetokens')
        )->addColumn(
            'md_id',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            null,
            ['identity' => true, 'nullable' => false, 'primary' => true],
            'Unique Id'
        )->addColumn(
            'md_appcode',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            255,
            ['nullable' => false],
            'appcode'
        )->addColumn(
            'md_userid',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            255,
            ['nullable' => false],
            'user id'
        )->addColumn(
            'md_store_id',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            255,
            ['nullable' => false],
            'Store id'
        )->addColumn(
            'md_enable_push',
            \Magento\Framework\DB\Ddl\Table::TYPE_BOOLEAN,
            null,
            ['nullable' => false],
            'is enabled push'
        )->addColumn(
            'md_devicetype',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            255,
            ['nullable' => false],
            'Devicetype'
        )->addColumn(
            'md_devicetoken',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            255,
            ['nullable' => false],
            'DeviceToken'
        )->addColumn(
            'md_created_date',
            \Magento\Framework\DB\Ddl\Table::TYPE_TIMESTAMP,
            255,
            ['nullable' => false],
            'Creteddate'
        )->setComment(
            'Manager Device Tokens'
        );

        $installer->getConnection()->createTable($table);

        //create role

        /**
        * Create Warehouse role 
        */
        $role=$this->roleFactory->create();
        $role->setName('Delivery Person') //Set Role Name Which you want to create 
                ->setPid(0) //set parent role id of your role
                ->setRoleType(RoleGroup::ROLE_TYPE) 
                ->setUserType(UserContextInterface::USER_TYPE_ADMIN);
        $role->save();
        /* Now we set that which resources we allow to this role */
        $resource=['Magento_Backend::admin',
                    'Magento_Sales::sales',
                    //'Magento_Sales::create',
                    'Magento_Sales::actions_view', //you will use resource id which you want tp allow
                    'Magento_Sales::cancel',
                    'Magento_Sales::sales_operation',
                    'Magento_Sales::sales_order',
                    'Magento_Sales::actions',
                    'Magento_Sales::email'

                  ];
        /* Array of resource ids which we want to allow this role*/
        $this->rulesFactory->create()->setRoleId($role->getId())->setResources($resource)->saveRel();


        $installer->endSetup();
    }
}
