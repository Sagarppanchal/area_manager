<?php

/**
 * Grid Grid Model.
 * @author sagarppanchal@21062018
 */
namespace Mobicommerce\Area\Model;

use Mobicommerce\Area\Api\Data\GridInterface;

class Grid extends \Magento\Framework\Model\AbstractModel implements GridInterface
{
    /**
     * CMS page cache tag.
     */
    const CACHE_TAG = 'mobicommerce_area_records';

    /**
     * @var string
     */
    protected $_cacheTag = 'mobicommerce_area_records';

    /**
     * Prefix of model events names.
     *
     * @var string
     */
    protected $_eventPrefix = 'mobicommerce_area_records';

    /**
     * Initialize resource model.
     */
    protected function _construct()
    {
        $this->_init('Mobicommerce\Area\Model\ResourceModel\Grid');
    }
    /**
     * Get EntityId.
     *
     * @return int
     */
    public function getEntityId()
    {
        return $this->getData(self::ENTITY_ID);
    }

    /**
     * Set EntityId.
     */
    public function setEntityId($entityId)
    {
        return $this->setData(self::ENTITY_ID, $entityId);
    }

    /**
     * Get Title.
     *
     * @return varchar
     */
    public function getTitle()
    {
        return $this->getData(self::TITLE);
    }

    /**
     * Set Title.
     */
    public function setTitle($title)
    {
        return $this->setData(self::TITLE, $title);
    }

    /**
     * Get getUsers.
     *
     * @return varchar
     */
    public function getUsers()
    {
        return $this->getData(self::USERS);
    }

    /**
     * Set Content.
     */
    public function setUsers($content)
    {
        return $this->setData(self::USERS, $content);
    }

    public function getEmail()
    {
        return $this->getData(self::EMAIL);
    }

    /**
     * Set Content.
     */
    public function setEmail($content)
    {
        return $this->setData(self::EMAIL, $content);
    }
}
