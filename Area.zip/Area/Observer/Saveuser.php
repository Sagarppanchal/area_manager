<?php

namespace Mobicommerce\Area\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;

class Saveuser implements \Magento\Framework\Event\ObserverInterface
{
	public function execute(Observer $observer)
	{

		echo 'herereyah';
		die;
		$displayText = $observer->getData('mp_text');
		echo $displayText->getText() . " - Event </br>";
		$displayText->setText('Execute event successfully.');

		return $this;
	}
}
