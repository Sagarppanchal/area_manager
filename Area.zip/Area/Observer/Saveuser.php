<?php

namespace Mobicommerce\Area\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;

class Saveuser implements \Magento\Framework\Event\ObserverInterface
{
	public function execute(Observer $observer)
	{

		// echo '<pre>';
		// print_r($observer->getRequest());
		// die;

		// $request =  $observer->getRequest()->getRequest();
		// //$posts = $request->getPost()->toArray();

		// echo '<pre>';
		// print_r($request);
		// die;

		//  // //custom @sagarppanchal:25062018

  //  //      $data['delivery_area']=implode(',', $data['delivery_area']);

		// $post_data = new \Zend\Stdlib\Parameters($posts);
		
		// $request->setPost($post_data);

		//echo '<pre>';
		// print_r($_REQUEST);
		// $userRoles = $this->getRequest()->getParam('delivery_area', []);
  //       // if (count($userRoles)) {
  //       //     $model->setRoleId($userRoles[0]);
  //       // }

  //       echo '<pre>';
  //       print_r($userRoles);

		// die;
		// $displayText = $observer->getData('mp_text');
		// echo $displayText->getText() . " - Event </br>";
		// $displayText->setText('Execute event successfully.');

		//return $this;
	}
}
