<?php

namespace Mobicommerce\Area\Observer;

//use Magento\Framework\Event\Observer;
//use Magento\Framework\Event\ObserverInterface;

class Saveorderafter implements \Magento\Framework\Event\ObserverInterface
{
	protected $logger;
	public function __construct(\Psr\Log\LoggerInterface $logger)
	{
	    $this->logger = $logger;
	}
	public function execute(\Magento\Framework\Event\Observer $observer)
	{
		$order = $observer->getEvent()->getOrder();
		$orderId = $order->getId();
		$shippingAddress = $order->getShippingAddress();
		$postcode = $order->getShippingAddress()->getData('postcode');

		$this->logger->info(json_encode($order->getShippingAddress()->getData()));

		$street2 = explode(PHP_EOL,$order->getShippingAddress()->getData('street'));
		
		if(isset($street2[1])){
			$area = $street2[1];
			$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
			$resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
			$connection = $resource->getConnection();
			$tableName = $resource->getTableName('mobicommerce_area_records');

			$sql = "Select * FROM " . $tableName." 
					WHERE `title` = '".$area."'";
			$result = $connection->fetchAll($sql);

			//update here
			$sales = $resource->getTableName('sales_order_grid');
			$sqls = "Update `sales_order_grid` Set area_manager = '".$result[0]['users']."' where entity_id = '".$order->getId()."'";
			$connection->query($sqls);

			//$order = $observer->getEvent()->getOrder();

			// $areamanager = $result[0]['users'];
			// $order->setData('area_manager',$areamanager);
			// $order->save();

			//$this->logger->info(json_encode($sqls));
		}
	}
}
