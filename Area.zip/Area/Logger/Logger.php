<?php
/**
 * Grid Schema Setup.
 * @author sagarppanchal@21062018
 */
namespace Mobicommerce\Area\Logger;

class Logger extends \Monolog\Logger
{

}
